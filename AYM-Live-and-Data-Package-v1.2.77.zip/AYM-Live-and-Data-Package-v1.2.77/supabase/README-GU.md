# AYM Smart Ledger + Supabase

આ packageની `site/index.html` હવે Supabase Starter સાથે Admin ledger sync કરે છે.

## આ sync શું કરે છે

- Adminનું સંપૂર્ણ ledger `public.aym_ledger_snapshots`માં એક organization row તરીકે રાખે છે.
- Push/pull પહેલાં Supabase Auth access token અને `aym_org_members`માં `admin`, active membership ચકાસે છે.
- Token refresh કરીને આ browserમાં session રાખે છે. Supabase password ક્યારેય local storageમાં સેવ થતો નથી.
- Party login અથવા appની local Admin login એકલાથી full ledger snapshot access મળતો નથી. Party ledger માટે અલગ scoped API/schema જોઈએ; આ starter એ permission આપતું નથી.
- `service_role`/secret key browserમાં મૂકાતી નથી.

## એક વાર backend તૈયાર કરો

1. Supabase Dashboardમાં Admin માટે Email + Password Auth user બનાવો. આ Supabase Auth login, એપના Admin username/passwordથી અલગ છે.
2. Supabase CLIથી આ project link કરીને `supabase db push` ચલાવો. તે `202611030001` અને `202611030002` migrations લાગુ કરશે.
3. `seed.example.sql`ની રીતથી `aym_organizations` row બનાવો અને મળેલી organization UUID સાથે Admin Auth userનો UUID `aym_org_members`માં `role='admin'`, `is_active=true` તરીકે ઉમેરો. Placeholder બદલીને જ SQL ચલાવો.
4. `site/licensing-config.json`માં Project URL અને publishable key છે. Key public જ છે; કોઈ secret key ઉમેરશો નહીં.
5. GitHub Pages પર `site/`ની ફાઇલો publish કરો.

`party-bootstrap` functionને party membership mapping માટે તૈયાર રાખ્યું છે: `supabase functions deploy party-bootstrap`થી deploy કરો. હાલનું Admin snapshot sync membership સીધું RLS હેઠળ ચકાસે છે; function Party ledger data વાંચતું નથી.

## દરેક Admin deviceમાં જોડો

1. એપમાં સામાન્ય Admin accountથી sign in કરો.
2. **Settings → Cloud Sync → Supabase** પસંદ કરો.
3. Project URL, publishable key, Organization UUID અને Supabase Admin email નાખો.
4. Supabase Admin password નાખીને **Supabaseમાં સાઇન ઇન** દબાવો. Password ખાલી થઈ જશે. Statusમાં active Admin membership ચકાસાઈ બતાવવું જોઈએ.
5. **સેવ** કરો; પછી **ઓટો સિંક** ચાલુ કરો અથવા **મોકલો / લાવો** દબાવો.
6. બીજા Admin computer/phoneમાં પણ આ જ URL, key અને organization UUID નાખીને તે જ અથવા બીજા active Admin Supabase accountથી sign in કરો.

## Party અને permissions

`aym_ledger_snapshots`માં Party માટે SELECT/INSERT/UPDATE policy નથી. તેથી Party device આ સંપૂર્ણ ledger sync કરી શકતું નથી. `party-bootstrap` function authenticated callerની organization, role અને `party_ref` આપે છે; તે પોતે party-scoped ledger data endpoint નથી. Party forms/messages/entriesને devices વચ્ચે મોકલવા માટે અલગ table/API અને દરેક record માટે `party_ref` આધારિત server-side policy ઉમેરવી પડશે.

## Troubleshooting

- **Admin membership નથી**: Dashboardમાં Auth user UUID તપાસો અને `aym_org_members`ની organization UUID/role/active flag સરખાં કરો.
- **HTTP 401**: Supabase URL/key તપાસો અને ફરી sign in કરો.
- **HTTP 403 / RLS**: migrations deploy થયા છે કે નહીં અને signed-in user active Admin છે કે નહીં તપાસો.
- **HTTP 404 / relation missing**: `supabase db push` સફળ થયું છે તેની ખાતરી કરો.
- **no row / ડેટા નથી**: પહેલી વાર `મોકલો` દબાવી snapshot બનાવો.

Auth token આ browserના local storageમાં session ચલાવવા માટે રહે છે; password ત્યાં સંગ્રહાતો નથી. Shared/public computerમાં કામ પૂરુ થયા પછી **સાઇન આઉટ** કરો. Publishable key અને user JWT clientમાં વપરાય છે; actual table access દરેક request પર Postgres RLSથી નિયંત્રિત થાય છે.
