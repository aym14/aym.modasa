-- Keep snapshot revision/time server-managed after each authenticated Admin write.
create or replace function public.aym_touch_ledger_snapshot()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at := now();
  if tg_op = 'UPDATE' then
    new.revision := old.revision + 1;
  else
    new.revision := 1;
  end if;
  return new;
end;
$$;

revoke all on function public.aym_touch_ledger_snapshot() from public, anon, authenticated;

drop trigger if exists aym_ledger_snapshot_touch on public.aym_ledger_snapshots;
create trigger aym_ledger_snapshot_touch
before insert or update on public.aym_ledger_snapshots
for each row execute function public.aym_touch_ledger_snapshot();
