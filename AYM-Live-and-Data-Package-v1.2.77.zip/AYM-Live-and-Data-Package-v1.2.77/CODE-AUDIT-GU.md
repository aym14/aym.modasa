# કોડ સમીક્ષા — AYM Smart Ledger v1.2.77

આ releaseમાં main HTML, inline JavaScript/CSS, PWA service worker અને Supabase starter filesનું static review કર્યું છે.

## સુધારેલી ખામીઓ

- UIમાં current app version અને embedded update metadata વચ્ચેની mismatch દૂર કરી; સમાન build ખોટી રીતે “નવું update” તરીકે દેખાતું હતું.
- Report generation/exportમાં string amount ને જોડાણ તરીકે ગણાવાની ભૂલ સુધારી અને malformed rows માટે safe handling ઉમેર્યું.
- CSV exportમાં quotes, commas અને line breaks ધરાવતા લખાણને યોગ્ય રીતે escape કર્યું.
- Party/member નામો HTML markup તરીકે inject થવાને બદલે text તરીકે render થાય છે.
- Service worker હવે મુખ્ય `index.html` cache ન કરી શકે તો નવો worker install કરતો નથી; હાલની offline આવૃત્તિ અખંડ રહે છે.
- Supabase sync હવે જૂની shared `ledger_data` table/Sync Key રીતની જગ્યાએ `aym_ledger_snapshots` વાપરે છે.
- Push/pull પહેલાં Supabase Auth session refresh થાય છે અને `aym_org_members`માં signed-in userની active Admin membership તપાસાય છે.
- Supabase password persist થતું નથી; Party accountને full ledger snapshot read/write policy મળતી નથી.

## બાકી રહેલી backend મર્યાદા

Supabase Admin full-ledger sync appમાં wired છે, પણ live projectમાં migrations લાગુ થયાં છે, Admin Auth user/membership બનાવ્યાં છે અને sign-in સફળ થયું છે તે અહીંથી ચકાસ્યું નથી. Party login હજુ આ deviceના local Party/User recordsમાંથી ઓળખ શોધે છે. Party forms/messages/entriesનું scoped multi-device sync આ releaseમાં નથી; તે માટે party-scoped endpoint/schema અને RLS જરૂરી છે.

આ code review છે; browser/device વર્તન અથવા live Supabase deployment અહીં ચલાવીને ચકાસ્યાં નથી. તેથી “દરેક bug દૂર થયો” એવી runtime ખાતરી આપી શકાતી નથી.
