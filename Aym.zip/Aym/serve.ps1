$root = "C:\Users\Abbas Ansari\Documents\Qoder\2026-11-04\55d0e420\AYM-Ledger-v1.2.80"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:8731/")
$listener.Start()
Write-Host "listening on http://localhost:8731/"
$mime = @{ ".html"="text/html; charset=utf-8"; ".js"="text/javascript"; ".json"="application/json"; ".png"="image/png"; ".css"="text/css" }
while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  $path = [System.Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath)
  if ($path -eq "/" -or $path -eq "") { $path = "/index.html" }
  $file = Join-Path $root ($path -replace "^[\\/]", "" -replace "[\\/]", "\")
  if (Test-Path $file -PathType Leaf) {
    $bytes = [System.IO.File]::ReadAllBytes($file)
    $ext = [System.IO.Path]::GetExtension($file).ToLower()
    if ($mime.ContainsKey($ext)) { $ctx.Response.ContentType = $mime[$ext] }
    $ctx.Response.Headers.Add("Cache-Control","no-store")
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  } else {
    $ctx.Response.StatusCode = 404
    $buf = [System.Text.Encoding]::UTF8.GetBytes("not found")
    $ctx.Response.OutputStream.Write($buf, 0, $buf.Length)
  }
  $ctx.Response.Close()
}
