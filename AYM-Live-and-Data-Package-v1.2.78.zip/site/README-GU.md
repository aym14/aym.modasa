# AYM Smart Ledger v1.2.78 — Supabase Ledger Sync

## Party QR

900px કે તેથી વધુ પહોળાઈએ desktop split layout દેખાય છે, ભલે browser viewportની ઊંચાઈ ઓછી હોય. ઓછી ઊંચાઈમાં panelsની અંદર scroll થાય છે. નાની screenમાં ઉપર organization brand row અને એક Party OTP login card દેખાય છે. QR link `?login=party` સાથે Party tab ખોલે છે; Admin tab ઉપલબ્ધ રહે છે. Desktop brand side અને **Settings → Party app QR**માં એક જ public QR છે, જેને Admin PNG તરીકે ડાઉનલોડ કરી શકે છે. QRમાં Party password, વ્યક્તિગત ઓળખની વિગતો કે Cloud Sync key નથી. QR એપ ખોલે છે; APK સીધી ડાઉનલોડ કરતું નથી.

દરેક Party પોતાનો નોંધાયેલ મોબાઇલ/OTP વાપરે. Androidમાં browser menu → **Install app** અને iPhoneમાં Share → **Add to Home Screen** પસંદ કરી શકાય.

Adminના બીજા વિશ્વાસપાત્ર ડિવાઇસ માટેનો Cloud Sync Join QR અલગ છે અને તે **Settings → Cloud Sync**માં જ વાપરવો.

## Party data privacy અને cloud scope

આ releaseમાં Supabase Admin-only snapshot sync લાગુ છે. Partyનું પોતાનું ડેટા server-side અલગ પાડવાની વ્યવસ્થા અહીંથી પૂર્ણ થતી નથી. Supabase Auth OTPની ચકાસણી પોતે ledger table પર Party-scoped access બનાવતી નથી. Party directory lookup પણ હાલ local ledger data પર આધારિત છે. Client-side filter પૂરતો સુરક્ષા ઉપાય નથી.

Party accountsને productionમાં પોતાના ledger data આપવા પહેલાં server-side Supabase Auth/RLS આધારિત party bootstrap/read/write endpoint, Party ID mapping અને party-scoped sync model deploy કરવી જરૂરી છે. `using (true)` જેવી public RLS policy ઉમેરશો નહીં. Service-role key HTMLમાં ન મૂકો.

## GitHub Pages ફાઇલો

આ ફોલ્ડરની બધી ફાઇલો, ખાસ કરીને `index.html`, `manifest.json`, `sw.js`, `icons/` અને `licensing-config.json`, GitHub Pagesના rootમાં રાખો.
