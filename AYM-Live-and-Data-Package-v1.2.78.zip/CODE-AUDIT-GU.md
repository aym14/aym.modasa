# કોડ સમીક્ષા — AYM Smart Ledger v1.2.78

આ releaseમાં main HTML, inline JavaScript/CSS, PWA service worker અને Supabase starter filesનું static review કર્યું છે.

## સુધારેલી ખામીઓ

- UIમાં current app version અને embedded update metadata વચ્ચેની mismatch દૂર કરી; સમાન build ખોટી રીતે “નવું update” તરીકે દેખાતું હતું.
- Report generation/exportમાં string amount ને જોડાણ તરીકે ગણાવાની ભૂલ સુધારી અને malformed rows માટે safe handling ઉમેર્યું.
- CSV exportમાં quotes, commas અને line breaks ધરાવતા લખાણને યોગ્ય રીતે escape કર્યું.
- Party/member નામો HTML markup તરીકે inject થવાને બદલે text તરીકે render થાય છે.
- Service worker હવે મુખ્ય `index.html` cache ન કરી શકે તો નવો worker install કરતો નથી; હાલની offline આવૃત્તિ અખંડ રહે છે.
- Supabase sync હવે જૂની shared `ledger_data` table/Sync Key રીતની જગ્યાએ `aym_ledger_snapshots` વાપરે છે.
- Push/pull પહેલાં Supabase Auth session refresh થાય છે અને `aym_org_members`માં signed-in userની active Admin membership તપાસાય છે.
- Supabase password persist થતું નથી; Party accountને full ledger snapshot read/write policy મળતી નથી.

## Live Supabase સ્થિતિ — 2026-11-04

- આપેલી Supabase URL અને publishable key સાથે Auth settings endpoint `HTTP 200` આપે છે.
- `aym_organizations`, `aym_org_members` અને `aym_ledger_snapshots` REST endpoints `HTTP 404` આપે છે. તેથી migrations/ટેબલ્સ આ projectમાં હાલ ઉપલબ્ધ નથી અને ledger push/pullનું end-to-end પરીક્ષણ કરી શકાયું નથી.
- આ તપાસ read-only હતી; કોઈ ledger data લખાયો નથી.
- Party forms/messages/entriesનું scoped multi-device sync આ releaseમાં નથી; તે માટે party-scoped endpoint/schema અને RLS જરૂરી છે.

Browserમાં app sign-in અને ledger push/pullનો runtime test હજી બાકી છે. Tables deploy થયા પછી Admin Auth user, active Admin membership અને organization UUID સાથે ફરી પરીક્ષણ જરૂરી છે.