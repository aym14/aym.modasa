# AYM Smart Ledger v1.2.78 — Supabase Ledger Sync

આ ZIPમાં સુધારેલી વેબ એપ અને Supabase માટેનો સુરક્ષિત શરૂઆતનો ઢાંચો છે.

## v1.2.78માં કરેલા કોડ સુધારા

- એપ વર્ઝન, embedded update metadata અને service-worker cache version સરખાં કર્યા.
- રિપોર્ટના totals numeric values તરીકે ગણાય છે; malformed rowsથી report તૂટતો નથી.
- CSV exportમાં comma, quotes અને નવી લાઇન યોગ્ય રીતે escape થાય છે.
- Party નામ/વિગત HTML markup તરીકે ન નાખતા text તરીકે render થાય છે.
- Offline updateમાં મુખ્ય index cache ન થાય તો નવો service worker install થતો અટકે છે, તેથી જૂની offline આવૃત્તિ સુરક્ષિત રહે છે.
- Supabase syncને Starterના `aym_ledger_snapshots` સાથે જોડ્યું; Admin Auth token, active organization membership અને RLS જરૂરી છે.
- Supabase password સેવ થતું નથી; Party માટે full-ledger snapshot access આપતું નથી.

## Live Supabase project check

- Supabase URL અને public publishable key આ project માટે ગોઠવ્યાં છે.
- 2026-11-04ની read-only ચકાસણીમાં Supabase Auth settings endpoint `HTTP 200` આપ્યો.
- `aym_organizations`, `aym_org_members` અને `aym_ledger_snapshots` REST endpoints `HTTP 404` આપ્યા; આ tables/schema હજી આ projectમાં દેખાતા નથી. તેથી live ledger push/pull થઈ શક્યું નથી અને કોઈ data લખાયો નથી.
- પહેલા `supabase db push` કરો, પછી organization અને active Admin membership બનાવો. ત્યારબાદ appમાં Supabase Admin તરીકે sign in કરો, Organization UUID દાખલ કરો અને sync ફરી ચકાસો.

## GitHub Pages

`site/`ની અંદરની બધી ફાઇલો Pagesના publish rootમાં અપલોડ કરો. `index.html` સીધી rootમાં રહેવી જોઈએ; `icons/` પણ તેની બાજુમાં જ રહેવું જોઈએ.

જરૂરી ફાઇલો:

- `index.html` — એપ
- `licensing-config.json` — Admin license કનેક્શન
- `manifest.json`, `sw.js` — install અને offline support
- `icons/` — એપના icons

`README-GU.md` માત્ર માર્ગદર્શન છે; તેને અપલોડ કરવું ફરજિયાત નથી.

## Supabase backend

`supabase/`માં organization/user mapping, Admin-only ledger snapshot અને authenticated `party-bootstrap` Edge Function છે. એપમાં Settings → Cloud Sync → Supabase પરથી Supabase Auth sign-in કરીને ledger મોકલી/લાવી શકાય છે.

Supabase CLI વડે project link કરીને `supabase db push` ચલાવો. Admin Supabase Auth user બનાવો, `aym_organizations` અને `aym_org_members`માં organization અને active Admin membership ઉમેરો. વિગત `supabase/README-GU.md`માં છે.

## Access મર્યાદા

આ releaseમાં Supabase ledger snapshot ફક્ત active Admin membershipથી જ વાંચી/લખી શકાય છે. Party accountsને આ full snapshotનો access નથી. Partyના forms/messages/entriesનું અલગ cloud sync હજુ આ packageમાં નથી; તેના માટે party-scoped API/schema અને RLS જરૂરી છે.

Appનો Admin login અને Supabase Auth login બે અલગ credentials છે. SMS/email OTP provider settings Supabase Dashboardમાં ગોઠવો.

કોઈ service-role key, database password કે SMS provider secret GitHubમાં ન મૂકો. Frontendમાં માત્ર public publishable key જ રાખવી.

