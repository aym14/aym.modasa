# AYM Smart Ledger — જરૂરી ફાઇલો

આ clean packageમાં PWA માટેની ફાઇલો અને Supabase membership/audit setup માટેની ફાઇલો જ રાખી છે.

## GitHub Pages

`site/`ની અંદરની બધી ફાઇલો Pagesના publish rootમાં મૂકો. `index.html`, `manifest.json`, `sw.js`, `licensing-config.json` અને `icons/` એક જ સ્તરે રહેવા જોઈએ.

`site/licensing-config.json`માં Supabase URL અને `publishable` key છે. આ browser configuration છે. Secret અથવા `service_role` key અહીં ક્યારેય ન મૂકો.

## Supabase migrations

Packageના rootમાંથી:

1. `supabase link --project-ref <તમારો-project-ref>` ચલાવો.
2. `supabase db push` ચલાવો.
3. `supabase/seed.example.sql`માં placeholdersને તમારા organization અને Supabase Auth user IDsથી બદલીને seed SQL અલગથી ચલાવો.

Migrations organization membership, role constraints અને append-only `aym_audit_events` table બનાવે છે. Audit વાંચવા અને privileged rolesથી લખવા Supabase MFA `aal2` જરૂરી છે.

## શું નોંધાય છે

- Appમાં છેલ્લા 400 structured events આ device પર રહે છે; login success/failure, OTP failure, logout, permission ફેરફાર અને record ફેરફાર નોંધાય છે.
- Supabase Auth session અને એક active organization membership ધરાવતા Party events server audit tableમાં best-effort મોકલાય છે.
- Admin login અને ledger હજી local છે; તેથી Admin events server tableમાં નહીં જાય અને server audit local ledger ફેરફારોનો authoritative પુરાવો નથી.
- નવી local નોંધોમાં password, OTP, token કે નાણાકીય વિગતો નથી. જૂના device-local audit entriesમાં જૂની વિગતો રહી શકે છે.

`party-bootstrap` Edge Function, duplicate deployment guides અને historical code-audit file કાઢ્યાં છે; હાલની `site/index.html`માંથી એ function call થતો નથી.
