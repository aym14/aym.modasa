-- Structured activity audit trail for authenticated AYM organization members.
-- Ledger records remain local in this package; this table records app events only.

alter table public.aym_org_members
  drop constraint if exists aym_org_members_role_check;

alter table public.aym_org_members
  add constraint aym_org_members_role_check
  check (role in ('owner', 'admin', 'treasurer', 'cashier', 'president', 'auditor', 'viewer', 'party'));

alter table public.aym_org_members
  drop constraint if exists aym_org_members_party_ref_check;

alter table public.aym_org_members
  add constraint aym_org_members_party_ref_check
  check (
    (role in ('party', 'viewer') and nullif(btrim(party_ref), '') is not null)
    or (role not in ('party', 'viewer') and party_ref is null)
  );

create table if not exists public.aym_audit_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.aym_organizations(id) on delete restrict,
  actor_user_id uuid not null default auth.uid(),
  event_type text not null check (event_type ~ '^[a-z][a-z0-9_]{0,79}$'),
  object_type text check (object_type is null or length(object_type) <= 64),
  object_id text check (object_id is null or length(object_id) <= 120),
  outcome text not null default 'success' check (outcome in ('success', 'failed', 'denied')),
  source text not null default 'client' check (source in ('client', 'server')),
  request_id uuid,
  details jsonb not null default '{}'::jsonb check (jsonb_typeof(details) = 'object'),
  created_at timestamptz not null default now()
);

create index if not exists aym_audit_events_org_time_idx
  on public.aym_audit_events (organization_id, created_at desc);

create index if not exists aym_audit_events_actor_time_idx
  on public.aym_audit_events (actor_user_id, created_at desc);

alter table public.aym_audit_events enable row level security;

revoke all on public.aym_audit_events from public, anon, authenticated;
grant select on public.aym_audit_events to authenticated;
grant insert (organization_id, actor_user_id, event_type, object_type, object_id, outcome, source, request_id, details)
  on public.aym_audit_events to authenticated;

drop policy if exists aym_audit_events_member_insert on public.aym_audit_events;
create policy aym_audit_events_member_insert
  on public.aym_audit_events for insert to authenticated
  with check (
    actor_user_id = (select auth.uid())
    and source = 'client'
    and details = '{}'::jsonb
    and exists (
      select 1
      from public.aym_org_members m
      where m.organization_id = aym_audit_events.organization_id
        and m.auth_user_id = (select auth.uid())
        and m.is_active = true
        and (
          m.role not in ('owner', 'admin', 'treasurer', 'cashier', 'president', 'auditor')
          or (select auth.jwt() ->> 'aal') = 'aal2'
        )
    )
  );

drop policy if exists aym_audit_events_privileged_read on public.aym_audit_events;
create policy aym_audit_events_privileged_read
  on public.aym_audit_events for select to authenticated
  using (
    (select auth.jwt() ->> 'aal') = 'aal2'
    and exists (
      select 1
      from public.aym_org_members m
      where m.organization_id = aym_audit_events.organization_id
        and m.auth_user_id = (select auth.uid())
        and m.is_active = true
        and m.role in ('owner', 'admin', 'auditor')
    )
  );

create or replace function public.aym_audit_events_reject_mutation()
returns trigger
language plpgsql
set search_path = pg_catalog, public
as $$
begin
  raise exception 'aym_audit_events is append-only';
end;
$$;

revoke all on function public.aym_audit_events_reject_mutation() from public, anon, authenticated;

drop trigger if exists aym_audit_events_no_update_delete on public.aym_audit_events;
create trigger aym_audit_events_no_update_delete
  before update or delete on public.aym_audit_events
  for each row execute function public.aym_audit_events_reject_mutation();
